#Has code for the major part of the frontend for the Comic book Library using Streamlit
import streamlit as st
import pandas as pd
from PIL import Image
import requests
from streamlit_lottie import st_lottie
from Search_engine import *
from collab_filter import *

#adding favicon and name for the site
img=Image.open("book_icon.png")
st.set_page_config(page_title="Comics Library", page_icon=img)
st.cache()

#function to open css file
def local_css(file_name):
    with open(file_name) as f:
        st.markdown(f'<style>{f.read()}</style>', unsafe_allow_html=True)   
        
#function to use lottie animation
def load_lottie(url):
    r=requests.get(url)
    if r.status_code!=200:
        return None
    return r.json()

#no of books to display
no_of_books=st.sidebar.slider("Select No. of comics to display",1,10)

#Search Bar
with st.container():
    with st.form(key="search form"):
        col1,col2=st.columns([2,1])
        with col1:
            book_name=st.text_input(label="Comic name", placeholder="Enter Comic name to search")
        with col2:
            st.text("Search Comic")
            button_clicked=st.form_submit_button(label="Search")
        
#lottie file animation
with st.container():
    col1,col2=st.columns(2)
    with col1:
        url1=load_lottie("https://assets4.lottiefiles.com/packages/lf20_ViifFo.json")
        st_lottie(url1,height=400)
    with col2:
        url2=load_lottie("https://assets4.lottiefiles.com/packages/lf20_wsdpcof3.json")
        st_lottie(url2,height=400)

#Show search results  
if "search_state" not in st.session_state:
    st.session_state.search_state=False
if button_clicked or st.session_state.search_state:
    st.session_state.search_state=True
    st.header("Search results")
    st.subheader("Showing results for {}".format(book_name))
    search_bar(book_name,no_of_books)
def recall():
    st.session_state.search_state=False
    
#Sidebar for different filters and options
st.sidebar.header("Filters")
choice=st.sidebar.radio(label="Recommendation Filter", options=["Popularity","Collaborative Filtering","Releases","Liked Comics"], on_change=recall())
st.header(choice)

#calling Releases() to display the books depending on the year range
if choice == "Releases":
    year = st.sidebar.radio(label="Releases", options=["2010-2022","2000-2010","1990-2000"])
    st.subheader(year)
    if year == "2010-2022":
        Release(no_of_books,2010,2022)
    if year == "2000-2010":
        Release(no_of_books,2000,2010)
    if year == "1990-2000":
        Release(no_of_books,1990,2000)
        
#calling Collaborative() to display recommendation based on users who have the same taste of books as us
if choice == "Collaborative Filtering":
    Collaborative(no_of_books)

#calling Popularity() to display popular books based on total ratings of each book
if choice == "Popularity":
    Popular(no_of_books)

#calling Liked() to display the books which is in our liked books csv file
if choice == "Liked Comics":
    Liked(no_of_books)

#display lottie file for user icon
url3=load_lottie("https://assets7.lottiefiles.com/packages/lf20_FqsM4u.json")
with st.sidebar:
    st_lottie(url3)
    st.write("Signed in as User123")
    
#Feedback sections and contact (will recieve email on 16.yutika.184@gmail.com if send button is clicked)
with st.container():
    local_css("feedback.css")
    st.write("---")
    st.header("Please give your feedback")
    st.write("##")
    contact_form="""
    <form action="https://formsubmit.co/16.yutika.184@gmail.com" method="POST">
     <input type="hidden" name="_captcha" value="false">
     <input type="text" name="name" placeholder="Enter your name" required>
     <input type="email" name="email" placeholder="Enter your email" required>
     <textarea name="Message" placeholder="Your message here" required></textarea>
     <button type="submit">Send</button>
    </form>
    """
    lcol,rcol=st.columns(2)
    with lcol:
        st.markdown(contact_form,unsafe_allow_html=True)
    with rcol:
        st.empty()
