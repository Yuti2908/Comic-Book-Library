#Has code for search engine, Popularity filter and Year of Release filter
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
import re
from Display_books import *

#retrieving data of all the books (books_titles.json was created from a much larger file goodreads_books.json to reduce it from 2GB to 590MB)
titles =pd.read_json("comics_titles.json")
popular=titles.sort_values("ratings",ascending=False)

#function to send data to display() to print popular books
def Popular(num):
    global popular
    popular_books=popular.head(num)
    popular_books=popular_books.to_dict()
    popular_ids=popular["book_id"].keys()
    display(popular_ids,popular_books)

#function to send data to display() to print books based of year of release range
def Release(num,year1,year2):
    global popular
    release=popular[popular["publication_year"]>str(year1)]
    release=release[release["publication_year"]<=str(year2)]
    release=release.head(num)
    release=release.to_dict()
    release_books=release["book_id"].keys()
    display(release_books,release)    
    
#Making a tf*idf matrix which is the term frequency multiplied to inverse document frequency 
#so whatever we search is converted to tfidf vector and then compare the searched name to each row in the matrix
#and find the most similar rows
vectorizer = TfidfVectorizer()
tfidf = vectorizer.fit_transform(titles["mod_title"])

#function used to remove special characters and lower case the searched comic and then convert to vector
#and be compared with each row and store the similarity in between them and give results with highest ratings
def search(query,num,vectorizer):
    processed = re.sub("[^a-zA-Z0-9 ]", "", query.lower())
    query_vec = vectorizer.transform([query])
    similarity = cosine_similarity(query_vec, tfidf).flatten()
    indices = np.argpartition(similarity, -10)[-10:]
    results = titles.iloc[indices]
    results = results.sort_values("ratings", ascending=False)
    search_result=results.head(num)
    search_result=search_result.to_dict()
    book_search=search_result["book_id"].keys()
    display(book_search,search_result)

#function to send data to display() to print books based on the comic name searched
def search_bar(query,num):
    search(query,num,vectorizer)