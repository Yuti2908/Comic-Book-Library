#Has code for displaying the books and code to add books that are liked in liked_books.csv
import streamlit as st
from PIL import Image
import requests
import io
import pandas as pd

#function to retrieve liked books from csv file
def liked_books():
    my_books = pd.read_csv("liked_books.csv", index_col=0)
    my_books["book_id"] = my_books["book_id"].astype(str)
    my_books_dict = my_books.to_dict()
    return my_books, my_books_dict

#function to display book for a particular category by displaying the cover image, 
#title isbn code, url to goodreads publisher and year
#Also includes the Like system from line 33 depending on which our liked_books.csv file is changed
def display(book_num,book_dict):
    my_books, my_books_dict = liked_books()
    try:
        for x in book_num:
            with st.container():
                col1,col2,col3=st.columns([1,2,1])

                with col1:
                    #display cover image
                    img_url=requests.get(book_dict["cover_image"][x])
                    img_byte=io.BytesIO(img_url.content)
                    img=Image.open(img_byte)
                    st.image(img)

                with col2:
                    # display details of book
                    st.write("**{}**".format(book_dict["title"][x]))
                    st.write("ISBN : {}".format(book_dict["ISBN"][x]))
                    st.write("Publisher : {}".format(book_dict["publisher"][x]))
                    st.write("Year of Publication : {}".format(book_dict["publication_year"][x]))
                    st.write("[For more info >]({})".format(book_dict["url"][x]))
                st.write("---")

                with col3:
                        #Like system: if ticked book is in liked_books.csv then it wont be added again in the csv file
                        #if not ticked book gets liked and rated then it will be added to the top of liked_books.csv
                    like=st.checkbox("Like",key=x)
                    if like:
                        rate=st.selectbox("Ratings",("",1,2,3,4,5),key=x)
                        if rate!="":
                            new_book=pd.DataFrame({"user_id":{x:-1}, 
                                          "book_id":{x:book_dict["book_id"][x]}, 
                                          "rating":{x:rate}, 
                                          "title":{x:book_dict["title"][x]}, 
                                          "url":{x:book_dict["url"][x]}, 
                                          "cover_image":{x:book_dict["cover_image"][x]}, 
                                          "publisher":{x:book_dict["publisher"][x]}, 
                                          "publication_year":{x:book_dict["publication_year"][x]}, 
                                          "ISBN":{x:book_dict["ISBN"][x]}})
                            if new_book["book_id"][x] not in my_books_dict["book_id"].values():
                                my_books=pd.concat([new_book,my_books])
                                my_books.to_csv("liked_books.csv")
                        else:
                            st.warning("Please give rating to the book")
    except KeyError:
        st.write("")