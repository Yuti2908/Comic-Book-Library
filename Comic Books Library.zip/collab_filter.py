#Has code for Collaborative filter and Liked books filter
import pandas as pd
from scipy.sparse import coo_matrix
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from Display_books import *

#function to send data to display() to print liked books
def Liked(num):
    my_books = pd.read_csv("liked_books.csv", index_col=0)
    my_books["book_id"] = my_books["book_id"].astype(str)
    liked_books = my_books.head(num)
    liked_books = liked_books.to_dict()
    liked_ids = liked_books["book_id"].keys()
    display(liked_ids,liked_books)

def collaborative_filter():  
    #finding users similar to us
    csv_book_mapping = {}
    with open("book_id_map.csv", "r") as f:
        while True:
            line = f.readline()
            if not line:
                break
            csv_id, book_id = line.strip().split(",")
            csv_book_mapping[csv_id] = book_id

    #retrieve data for liked_books.csv
    my_books = pd.read_csv("liked_books.csv", index_col=0)
    my_books["book_id"] = my_books["book_id"].astype(str)

    book_set = set(my_books["book_id"])   
    
    overlap_users = {}
    #storing the users who have read the same books as us in overlap_users and also keep track 
    #of how many books in common were read
    with open("comic_interactions.csv", 'r') as f:
        while True:
            line = f.readline()
            if not line:
                break
            _, user_id, csv_id, rating = line.split(",")

            book_id = csv_book_mapping.get(csv_id)

            if book_id in book_set:
                if user_id not in overlap_users:
                    overlap_users[user_id] = 1
                else:
                    overlap_users[user_id] += 1
     
    #storing user_id, book_id and rating of similar users
    interactions_list = []
    with open("comic_interactions.csv", 'r') as f:
        while True:
            line = f.readline()
            if not line:
                break
            _, user_id, csv_id, rating = line.split(",")

            if user_id in overlap_users:
                book_id = csv_book_mapping[csv_id]
                interactions_list.append([user_id, book_id, rating])
    for x in range(len(interactions_list)):
        interactions_list[x][2]=interactions_list[x][2].strip('\n')

    #creating a user to book matrix and adding our liked books in it and make them of the required data types
    interactions = pd.DataFrame(interactions_list, columns=["user_id", "book_id", "rating"])
    interactions = pd.concat([my_books[["user_id", "book_id", "rating"]], interactions])
    interactions["book_id"] = interactions["book_id"].astype(str)
    interactions["user_id"] = interactions["user_id"].astype(str)
    interactions["rating"] = pd.to_numeric(interactions["rating"])
    interactions["user_index"] = interactions["user_id"].astype("category").cat.codes
    interactions["book_index"] = interactions["book_id"].astype("category").cat.codes

    #making a sparse matrix book to user matrix to reduce memory consumption when working with huge data
    #converting the coo matrix to csr matrix type
    ratings_mat_coo = coo_matrix((interactions["rating"], (interactions["user_index"], interactions["book_index"])))
    ratings_mat = ratings_mat_coo.tocsr()
    my_index = 0
    
    #finding users with more similarity in terms of ratings for the same books read
    similarity = cosine_similarity(ratings_mat[my_index,:], ratings_mat).flatten()
    indices = np.argpartition(similarity, -15)[-15:]

    #retrieving the user_ids of the above similar users and removing us from that similar users
    similar_users = interactions[interactions["user_index"].isin(indices)].copy()
    similar_users = similar_users[similar_users["user_id"]!="-1"]
    
    #filtering out the repeatition of any book in recommendations based on score 
    book_recs = similar_users.groupby("book_id").rating.agg(['count', 'mean'])
    
    #opening comic books file to merge the details of the book_ids that were recommended
    books_titles = pd.read_json("comics_titles.json")
    books_titles["book_id"] = books_titles["book_id"].astype(str)
    book_recs = book_recs.merge(books_titles, how="inner", on="book_id")
    
    #ranking the recommendations based popularity, mean and count
    book_recs["adjusted_count"] = book_recs["count"] * (book_recs["count"] / book_recs["ratings"])
    book_recs["score"] = book_recs["mean"] * book_recs["adjusted_count"]
    book_recs = book_recs[~book_recs["book_id"].isin(my_books["book_id"])]
    my_books["mod_title"] = my_books["title"].str.replace("[^a-zA-Z0-9 ]", "", regex=True).str.lower()
    my_books["mod_title"] = my_books["mod_title"].str.replace("\s+", " ", regex=True)
    book_recs = book_recs[~book_recs["mod_title"].isin(my_books["mod_title"])]
    book_recs = book_recs[book_recs["mean"] >=1]
    book_recs = book_recs[book_recs["count"]>=1]
    top_recs = book_recs.sort_values("mean", ascending=False)
    return top_recs

#function to send data to display() to print the collaborative filter recommendation books
def Collaborative(num):
    top_recs = collaborative_filter()
    collab = top_recs.head(num)
    collab = collab.to_dict()
    filter_books = collab["book_id"].keys()
    display(filter_books,collab)